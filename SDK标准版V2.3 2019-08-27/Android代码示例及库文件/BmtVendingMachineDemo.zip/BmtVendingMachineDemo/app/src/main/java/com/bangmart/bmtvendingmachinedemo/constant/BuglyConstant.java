package com.bangmart.bmtvendingmachinedemo.constant;

/**
 * Created by zhoujq on 2019/8/23.
 */
public interface BuglyConstant {
    String APPID="942384b451";
}
