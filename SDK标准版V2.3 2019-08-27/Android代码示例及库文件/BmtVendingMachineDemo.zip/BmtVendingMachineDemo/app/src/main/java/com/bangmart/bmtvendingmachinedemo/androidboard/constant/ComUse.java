package com.bangmart.bmtvendingmachinedemo.androidboard.constant;

/**
 * Created by zhoujq on 2019/1/22.
 */
public interface ComUse {
    /**
     * 自贩机
     */
    int VENDING_MACHINE=1;

    /**
     * 打印机
     */
    int PRINTER=2;
}
