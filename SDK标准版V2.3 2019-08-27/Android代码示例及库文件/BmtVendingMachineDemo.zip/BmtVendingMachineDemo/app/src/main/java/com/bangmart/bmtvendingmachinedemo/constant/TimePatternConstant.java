package com.bangmart.bmtvendingmachinedemo.constant;

/**
 * Created by zhoujq on 2017/4/18.
 */

public interface TimePatternConstant {
    String LOG_TIME_PATTERN="yyyy-MM-dd HH:mm:ss";
    String TIME_PATTERN_YEAR_TO_MIN="yyyy-MM-dd HH:mm";
    String TIME_PATTERN="MM-dd HH:mm";
    String DATE_PATTERN="MM-dd";
}
