package com.bangmart.bmtvendingmachinedemo.constant;

/**
 * Created by zhoujq on 2017/12/14.
 */

public interface ComId {
    int ID_ONE=1;
    int ID_TWO=2;
    int ID_THREE=3;
    int ID_FOUR=4;
    int ID_FIVE=5;
    int ID_SIX=6;
    int ID_SEVEN=7;
    int ID_EIGHT=8;
}
