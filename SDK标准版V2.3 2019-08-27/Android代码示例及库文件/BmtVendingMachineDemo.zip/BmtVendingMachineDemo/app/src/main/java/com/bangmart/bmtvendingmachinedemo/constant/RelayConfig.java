package com.bangmart.bmtvendingmachinedemo.constant;

/**
 * Created by zhoujq on 2019/7/3.
 * 继电器配置
 */
public interface RelayConfig {
    /**
     * 旧配置
     */
    int OLD_CONFIG=1;

    /**
     * 新配置
     */
    int NEW_CONFIG=2;
}
